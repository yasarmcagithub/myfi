<?php 

class animal
{
	public $name;

	function setname($n)
	{
        $this->name=$n.'<br>';
	}
	function getname()
	{
		echo $this->name; 
	}
}

$dog=new animal();
$dog->setname('dog');
$dog->getname();

$dog->setname('cat');
$dog->getname();


/**
 * 
 */
class car
{
	
	function audi()
	{
		echo 'audi <br>';
	}
	function bmw()
	{
		echo "bmw <br>";
	}
}
$car=new car();
$car->audi();


class fruite
{
	public $fname;

	function getname()
	{
		echo $this->fname; 
	}
}

$apple=new fruite();
$apple->fname="apple";
$apple->getname();


class mysql
	{

	//connection 

	  function connection($servername,$username,$password,$db="")
	  {
	  	if(mysqli_connect($servername,$username,$password,$db))
	  	{
	  		// echo $servername.$username .$password .$db ;
	  	}
	  	else
	  	{
	  		echo "<br> Not Connected";
	  	}
	  }
    
    //numrows
	  function runquery($con,$sqlquery,$resultmode="")
	  {
          if (mysqli_query($con,$sqlquery,$resultmode)) {
          	
          }
          else
          {
          	echo "<br> Query Not Execute";
          }
	  }

	}  //class end
$mysql=new mysql;
$connn=$mysql->connection("localhost","root","","demo");
$mysql->runquery($connn,"INSERT INTO demo (name) VALUES ('yasar')");


?>